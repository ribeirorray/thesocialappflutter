package com.example.musicplayer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
