import 'package:flutter/material.dart';
import 'package:musicplayer/pages/root_app.dart';

void main() async {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: RootApp(),
  ));
}
